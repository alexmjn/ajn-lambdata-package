def funcname(parameter_list):
    pass
